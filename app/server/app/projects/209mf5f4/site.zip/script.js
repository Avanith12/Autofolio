// Simple JS for future enhancements
console.log('Portfolio loaded');